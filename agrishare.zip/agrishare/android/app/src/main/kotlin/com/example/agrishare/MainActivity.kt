package com.example.agrishare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
